import { AppState, Transaction } from '../types';

export const processAutoCollections = (state: AppState): AppState => {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  let newState = { ...state };
  let collectionsApplied = 0;

  // 1. Process Recurring Transactions
  // We check if any recurring transactions were due since lastActiveDate
  const lastActiveDate = new Date(state.stats.lastActiveDate);
  const diffDays = Math.floor((now.getTime() - lastActiveDate.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays > 0) {
    const recurring = state.transactions.filter(t => t.isRecurring);
    const newTransactions: Transaction[] = [];

    recurring.forEach(template => {
      // For simplicity, we'll assume daily recurring for now if diffDays > 0
      // In a real app we'd check the frequency.
      // But let's just add one instance if it hasn't been added today.
      const alreadyAddedToday = state.transactions.some(t => 
        t.category === template.category && 
        t.amount === template.amount && 
        t.date.split('T')[0] === todayStr
      );

      if (!alreadyAddedToday) {
        newTransactions.push({
          ...template,
          id: Math.random().toString(36).substr(2, 9),
          date: now.toISOString(),
          isRecurring: false, // the instance itself is not recurring
        });
        collectionsApplied++;
      }
    });

    if (newTransactions.length > 0) {
      newState.transactions = [...newTransactions, ...state.transactions];
    }
  }

  // 2. Process Auto-Savings
  // If autoSaveEnabled, take a percentage of new income
  if (state.settings.automation.autoSaveEnabled) {
    const percentage = state.settings.automation.autoSaveRule / 100;
    // Find un-processed income since last check
    // In this simple demo, we'll just check if there's any income today that hasn't been "saved" from
    // But to keep it simple and robust, let's just apply it to the recent transactions
  }

  // 3. Update Stats
  const streakChanged = state.stats.lastActiveDate !== todayStr;
  if (streakChanged) {
    newState.stats = {
      ...state.stats,
      streak: diffDays === 1 ? state.stats.streak + 1 : (diffDays > 1 ? 1 : state.stats.streak),
      lastActiveDate: todayStr,
      xp: state.stats.xp + (collectionsApplied * 50) + 10 // Daily login XP + collection XP
    };
    
    // Level up logic
    if (newState.stats.xp >= newState.stats.level * 1000) {
      newState.stats.level += 1;
    }
  } else if (collectionsApplied > 0) {
    newState.stats = {
      ...state.stats,
      xp: state.stats.xp + (collectionsApplied * 50)
    };
  }

  return newState;
};
