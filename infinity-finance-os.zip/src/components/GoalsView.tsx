import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Target, 
  Plus, 
  ChevronRight, 
  Calendar, 
  TrendingUp, 
  Zap,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Shield,
  Trash2
} from 'lucide-react';
import { AppState, Goal } from '../types';
import { cn } from '../lib/utils';

interface GoalsViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

export default function GoalsView({ state, updateState }: GoalsViewProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [newGoal, setNewGoal] = useState<Partial<Goal>>({
    name: '',
    targetAmount: 0,
    currentAmount: 0,
    deadline: new Date().toISOString().split('T')[0],
    priority: 'medium'
  });

  const handleAddGoal = () => {
    if (!newGoal.name || !newGoal.targetAmount) return;

    const goal: Goal = {
      id: Math.random().toString(36).substr(2, 9),
      name: newGoal.name!,
      targetAmount: Number(newGoal.targetAmount),
      currentAmount: Number(newGoal.currentAmount) || 0,
      deadline: newGoal.deadline!,
      priority: newGoal.priority as 'high' | 'medium' | 'low',
      subGoals: []
    };

    updateState(prev => ({
      ...prev,
      goals: [...prev.goals, goal]
    }));

    setShowAddModal(false);
    setNewGoal({ name: '', targetAmount: 0, currentAmount: 0, deadline: new Date().toISOString().split('T')[0], priority: 'medium' });
  };

  const calculateProbability = (goal: Goal) => {
    const daysLeft = (new Date(goal.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24);
    const amountLeft = goal.targetAmount - goal.currentAmount;
    if (amountLeft <= 0) return 100;
    if (daysLeft <= 0) return 0;
    
    const requiredDaily = amountLeft / daysLeft;
    const currentDaily = state.stats.totalSaved / 30; // rough estimate
    
    return Math.min(100, Math.max(0, (currentDaily / requiredDaily) * 100));
  };

  const emergencyGoal = state.goals.find(g => g.name.toLowerCase().includes('emergency'));
  const emergencyProgress = emergencyGoal ? (emergencyGoal.currentAmount / emergencyGoal.targetAmount) * 100 : 0;

  const handleOptimize = () => {
    setIsOptimizing(true);
    
    updateState(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        automation: {
          ...prev.settings.automation,
          autoSaveEnabled: true,
          autoSaveRule: Math.min(100, prev.settings.automation.autoSaveRule + 5)
        }
      }
    }));

    // Reset state after 2 seconds
    setTimeout(() => {
      setIsOptimizing(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic">Quantum Goal Engine</h2>
          <p className="text-xs opacity-50 font-bold uppercase tracking-widest">Multi-layer targets & deadline intelligence</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-green-500 text-black p-3 rounded-xl hover:bg-green-400 transition-colors"
        >
          <Plus size={20} />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {state.goals.map((goal) => {
          const probability = calculateProbability(goal);
          const progress = (goal.currentAmount / goal.targetAmount) * 100;

          return (
            <motion.div 
              key={goal.id}
              whileHover={{ y: -4 }}
              className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-4 relative overflow-hidden group"
            >
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black tracking-tight">{goal.name}</h3>
                    {goal.priority === 'high' && (
                      <span className="text-[8px] px-1.5 py-0.5 bg-red-500/20 text-red-500 rounded border border-red-500/20 uppercase font-black">Priority</span>
                    )}
                    <button 
                      onClick={() => {
                        updateState(prev => ({
                          ...prev,
                          goals: prev.goals.filter(g => g.id !== goal.id)
                        }));
                      }}
                      className="p-1 bg-red-500/10 text-red-500 rounded hover:bg-red-500/20 transition-colors"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                  <p className="text-[10px] uppercase font-bold opacity-50 flex items-center gap-1">
                    <Calendar size={10} />
                    Deadline: {new Date(goal.deadline).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-black tracking-tighter">
                    {state.settings.currency}{goal.currentAmount.toLocaleString()}
                  </p>
                  <p className="text-[10px] uppercase font-bold opacity-30">
                    Target: {state.settings.currency}{goal.targetAmount.toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-bold uppercase">
                  <span className="opacity-50">Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    className={cn(
                      "h-full transition-all duration-1000",
                      progress > 80 ? "bg-green-500" : progress > 40 ? "bg-blue-500" : "bg-orange-500"
                    )}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <div className="p-3 rounded-2xl bg-white/5 border border-white/5 flex flex-col items-center justify-center gap-1">
                  <p className="text-[8px] uppercase font-bold opacity-50">Probability</p>
                  <p className={cn(
                    "text-xs font-black",
                    probability > 70 ? "text-green-400" : probability > 40 ? "text-yellow-400" : "text-red-400"
                  )}>{Math.round(probability)}%</p>
                </div>
                <div className="p-3 rounded-2xl bg-white/5 border border-white/5 flex flex-col items-center justify-center gap-1">
                  <p className="text-[8px] uppercase font-bold opacity-50">Status</p>
                  <p className="text-xs font-black text-blue-400">On Track</p>
                </div>
              </div>

              {/* Sub-goals preview */}
              {goal.subGoals.length > 0 && (
                <div className="pt-2 border-t border-white/5 space-y-2">
                  <p className="text-[8px] uppercase font-bold opacity-30">Sub-goals</p>
                  {goal.subGoals.map(sg => (
                    <div key={sg.id} className="flex items-center justify-between text-[10px]">
                      <span className="opacity-60">{sg.name}</span>
                      <span className="font-bold">{Math.round((sg.currentAmount / sg.targetAmount) * 100)}%</span>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Emergency Fund Builder Card */}
      <div className="p-8 rounded-[2rem] bg-gradient-to-br from-blue-600 to-indigo-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Shield size={120} />
        </div>
        <div className="relative z-10 space-y-4 max-w-md">
          <div className="flex items-center gap-2">
            <Shield size={24} />
            <h3 className="text-xl font-black uppercase tracking-tighter">Emergency Survival Mode</h3>
          </div>
          <p className="text-sm font-medium opacity-80 leading-relaxed">
            Your emergency fund is at {Math.round(emergencyProgress)}%. The system suggests increasing auto-contributions to {state.settings.automation.autoSaveRule + 5}% to reach "Safe Zone" faster.
          </p>
          <div className="flex items-center gap-4">
            <button 
              onClick={handleOptimize}
              disabled={isOptimizing}
              className={cn(
                "px-6 py-3 rounded-xl font-black text-xs uppercase transition-all flex items-center gap-2",
                isOptimizing 
                  ? "bg-green-500 text-black" 
                  : "bg-white text-blue-900 hover:bg-blue-50"
              )}
            >
              {isOptimizing ? (
                <>
                  <CheckCircle2 size={16} />
                  Optimized!
                </>
              ) : (
                <>
                  <Zap size={16} />
                  Optimize Now
                </>
              )}
            </button>
            <div className="flex flex-col">
              <span className="text-[10px] font-bold uppercase opacity-60">Current Rule</span>
              <span className="text-sm font-black">{state.settings.automation.autoSaveRule}%</span>
            </div>
          </div>
        </div>
      </div>
      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-zinc-900 border border-white/10 rounded-3xl p-6 w-full max-w-md space-y-4"
          >
            <h3 className="text-xl font-black uppercase tracking-tighter italic">New Financial Target</h3>
            
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Goal Name</label>
              <input 
                type="text" 
                value={newGoal.name || ''}
                onChange={(e) => setNewGoal(prev => ({ ...prev, name: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="e.g. New Car, House Downpayment"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Target Amount</label>
                <input 
                  type="number" 
                  value={newGoal.targetAmount || ''}
                  onChange={(e) => setNewGoal(prev => ({ ...prev, targetAmount: Number(e.target.value) }))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Initial Savings</label>
                <input 
                  type="number" 
                  value={newGoal.currentAmount || ''}
                  onChange={(e) => setNewGoal(prev => ({ ...prev, currentAmount: Number(e.target.value) }))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                  placeholder="0.00"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Deadline</label>
                <input 
                  type="date" 
                  value={newGoal.deadline || ''}
                  onChange={(e) => setNewGoal(prev => ({ ...prev, deadline: e.target.value }))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Priority</label>
                <select 
                  value={newGoal.priority}
                  onChange={(e) => setNewGoal(prev => ({ ...prev, priority: e.target.value as any }))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <button 
                onClick={() => setShowAddModal(false)}
                className="px-6 py-3 rounded-xl font-bold text-xs uppercase hover:bg-white/5 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleAddGoal}
                className="px-6 py-3 bg-green-500 text-black rounded-xl font-bold text-xs uppercase hover:bg-green-400 transition-colors"
              >
                Deploy Goal
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
