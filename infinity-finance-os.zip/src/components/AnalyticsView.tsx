import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart3, 
  PieChart as PieChartIcon, 
  TrendingUp, 
  TrendingDown, 
  Activity,
  Calendar,
  Layers,
  Zap
} from 'lucide-react';
import { AppState } from '../types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';

interface AnalyticsViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

export default function AnalyticsView({ state, updateState }: AnalyticsViewProps) {
  const categoryData = state.budgets.map(b => ({
    name: b.category,
    value: b.spent
  }));

  const COLORS = ['#4ade80', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

  const radarData = [
    { subject: 'Savings', A: Math.min(150, (state.stats.totalSaved / 1000) * 10), fullMark: 150 },
    { subject: 'Income', A: Math.min(150, (state.incomeSources.reduce((acc, s) => acc + s.amount, 0) / 100) * 10), fullMark: 150 },
    { subject: 'Budget', A: Math.min(150, (state.budgets.length * 20)), fullMark: 150 },
    { subject: 'Goals', A: Math.min(150, (state.goals.length * 30)), fullMark: 150 },
    { subject: 'Risk', A: state.settings.automation.riskTriggers.lowBalance ? 100 : 50, fullMark: 150 },
    { subject: 'Growth', A: Math.min(150, (state.stats.xp / 10)), fullMark: 150 },
  ];

  const projectionData = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const monthlyNet = state.incomeSources.reduce((acc, s) => acc + s.amount, 0) - 
                      state.budgets.reduce((acc, b) => acc + b.limit, 0);
    
    return Array.from({ length: 5 }, (_, i) => {
      const year = currentYear + i;
      const months = (i + 1) * 12;
      const base = state.stats.totalSaved + (monthlyNet * months);
      return {
        year: year.toString(),
        success: Math.max(0, base * 1.2),
        stable: Math.max(0, base),
        risk: Math.max(0, base * 0.7)
      };
    });
  }, [state]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic">Visual Analytics Core</h2>
          <p className="text-xs opacity-50 font-bold uppercase tracking-widest">Deep analytics & behavioral mapping</p>
        </div>
        <div className="flex gap-2">
          <button className="p-2 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold uppercase px-3">Export PDF</button>
          <button className="p-2 bg-green-500 text-black rounded-xl text-[10px] font-bold uppercase px-3">Live Replay</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending Distribution */}
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 mb-6 flex items-center gap-2">
            <PieChartIcon size={14} />
            Expense Distribution Map
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#000', border: '1px solid #ffffff20', borderRadius: '12px', fontSize: '10px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-4 mt-4">
            {categoryData.map((c, i) => (
              <div key={c.name} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <span className="text-[10px] font-bold uppercase opacity-60">{c.name}</span>
                <span className="text-[10px] font-bold ml-auto">{state.settings.currency}{c.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Financial Health Radar */}
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 mb-6 flex items-center gap-2">
            <Activity size={14} />
            Financial Health Radar
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                <PolarGrid stroke="#ffffff10" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#ffffff40', fontSize: 10 }} />
                <PolarRadiusAxis angle={30} domain={[0, 150]} tick={false} axisLine={false} />
                <Radar
                  name="Health"
                  dataKey="A"
                  stroke="#4ade80"
                  fill="#4ade80"
                  fillOpacity={0.3}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[10px] text-center opacity-40 uppercase font-bold mt-4">
            Balanced profile detected. Focus on "Growth" to reach Level 6.
          </p>
        </div>

        {/* Wealth Projection */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white/5 border border-white/10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
              <TrendingUp size={14} />
              Future Wealth Projection (5 Years)
            </h3>
            <div className="flex gap-2">
              <span className="flex items-center gap-1 text-[8px] font-bold uppercase text-green-400">
                <div className="w-2 h-2 rounded-full bg-green-400" /> Success
              </span>
              <span className="flex items-center gap-1 text-[8px] font-bold uppercase text-blue-400">
                <div className="w-2 h-2 rounded-full bg-blue-400" /> Stable
              </span>
              <span className="flex items-center gap-1 text-[8px] font-bold uppercase text-red-400">
                <div className="w-2 h-2 rounded-full bg-red-400" /> Risk
              </span>
            </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={projectionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="year" stroke="#ffffff40" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#ffffff40" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#000', border: '1px solid #ffffff20', borderRadius: '12px', fontSize: '10px' }}
                />
                <Bar dataKey="success" fill="#4ade80" radius={[4, 4, 0, 0]} />
                <Bar dataKey="stable" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="risk" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
