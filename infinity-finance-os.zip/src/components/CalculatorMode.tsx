import React, { useState } from 'react';
import { motion } from 'motion/react';

interface CalculatorModeProps {
  onUnlock: () => void;
}

export default function CalculatorMode({ onUnlock }: CalculatorModeProps) {
  const [display, setDisplay] = useState('0');
  const [history, setHistory] = useState('');

  const handleInput = (val: string) => {
    if (display === '0') setDisplay(val);
    else setDisplay(prev => prev + val);
    
    // Secret sequence to unlock: 123456
    if (display + val === '123456') {
      onUnlock();
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setHistory('');
  };

  const handleOp = (op: string) => {
    setHistory(display + ' ' + op);
    setDisplay('0');
  };

  const handleEqual = () => {
    try {
      const parts = history.split(' ');
      if (parts.length < 2) return;
      
      const num1 = parseFloat(parts[0]);
      const op = parts[1];
      const num2 = parseFloat(display);
      
      let result = 0;
      switch (op) {
        case '+': result = num1 + num2; break;
        case '-': result = num1 - num2; break;
        case '*': result = num1 * num2; break;
        case '/': result = num1 / num2; break;
        case '%': result = num1 % num2; break;
        default: result = num2;
      }
      
      setDisplay(String(result));
      setHistory('');
    } catch {
      setDisplay('Error');
    }
  };

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center p-6 z-[300]">
      <div className="w-full max-w-xs bg-zinc-900 p-4 rounded-[2.5rem] shadow-2xl border border-white/5">
        {/* Display */}
        <div className="h-32 flex flex-col justify-end items-end p-4 mb-4">
          <span className="text-zinc-500 text-sm font-bold h-6">{history}</span>
          <span className="text-white text-5xl font-light tracking-tight overflow-hidden text-ellipsis w-full text-right">
            {display}
          </span>
        </div>

        {/* Buttons */}
        <div className="grid grid-cols-4 gap-3">
          <CalcBtn label="AC" color="zinc" onClick={handleClear} />
          <CalcBtn label="+/-" color="zinc" onClick={() => {}} />
          <CalcBtn label="%" color="zinc" onClick={() => handleOp('%')} />
          <CalcBtn label="÷" color="orange" onClick={() => handleOp('/')} />
          
          <CalcBtn label="7" onClick={() => handleInput('7')} />
          <CalcBtn label="8" onClick={() => handleInput('8')} />
          <CalcBtn label="9" onClick={() => handleInput('9')} />
          <CalcBtn label="×" color="orange" onClick={() => handleOp('*')} />
          
          <CalcBtn label="4" onClick={() => handleInput('4')} />
          <CalcBtn label="5" onClick={() => handleInput('5')} />
          <CalcBtn label="6" onClick={() => handleInput('6')} />
          <CalcBtn label="-" color="orange" onClick={() => handleOp('-')} />
          
          <CalcBtn label="1" onClick={() => handleInput('1')} />
          <CalcBtn label="2" onClick={() => handleInput('2')} />
          <CalcBtn label="3" onClick={() => handleInput('3')} />
          <CalcBtn label="+" color="orange" onClick={() => handleOp('+')} />
          
          <CalcBtn label="0" span={2} onClick={() => handleInput('0')} />
          <CalcBtn label="." onClick={() => handleInput('.')} />
          <CalcBtn label="=" color="orange" onClick={handleEqual} />
        </div>
      </div>
      <p className="mt-8 text-[10px] uppercase font-bold text-zinc-800 tracking-widest">Standard Calculator v1.0.4</p>
    </div>
  );
}

function CalcBtn({ label, color = 'dark', span = 1, onClick }: { label: string, color?: 'zinc' | 'orange' | 'dark', span?: number, onClick: () => void }) {
  const bg = {
    zinc: 'bg-zinc-400 text-black hover:bg-zinc-300',
    orange: 'bg-orange-500 text-white hover:bg-orange-400',
    dark: 'bg-zinc-800 text-white hover:bg-zinc-700'
  }[color];

  return (
    <button 
      onClick={onClick}
      className={`${bg} h-14 rounded-full text-xl font-medium transition-all active:scale-90 ${span === 2 ? 'col-span-2 text-left px-6' : ''}`}
    >
      {label}
    </button>
  );
}
