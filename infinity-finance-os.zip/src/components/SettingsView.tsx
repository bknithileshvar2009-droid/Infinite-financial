import React from 'react';
import { motion } from 'motion/react';
import { 
  Settings, 
  Shield, 
  Moon, 
  Sun, 
  Zap, 
  Lock, 
  Eye, 
  Download, 
  Upload, 
  Trash2,
  Globe,
  Bell,
  Fingerprint,
  Calculator,
  Scan,
  Github,
  Cloud,
  CloudOff,
  Database,
  LogIn,
  LogOut
} from 'lucide-react';
import { AppState } from '../types';
import { cn } from '../lib/utils';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';

interface SettingsViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export default function SettingsView({ state, updateState, showToast }: SettingsViewProps) {
  const toggleTheme = (theme: 'dark' | 'light' | 'neon') => {
    updateState(prev => ({
      ...prev,
      settings: { ...prev.settings, theme }
    }));
  };

  const toggleFakeMode = () => {
    updateState(prev => ({
      ...prev,
      settings: { 
        ...prev.settings, 
        security: { ...prev.settings.security, fakeAppMode: !prev.settings.security.fakeAppMode } 
      }
    }));
  };

  const toggleDecoyMode = () => {
    updateState(prev => ({
      ...prev,
      settings: { 
        ...prev.settings, 
        security: { ...prev.settings.security, decoyMode: !prev.settings.security.decoyMode } 
      }
    }));
  };

  const toggleBiometric = (type: 'fingerprint' | 'faceId') => {
    updateState(prev => ({
      ...prev,
      settings: { 
        ...prev.settings, 
        security: { 
          ...prev.settings.security, 
          biometrics: { 
            ...prev.settings.security.biometrics, 
            [type]: !prev.settings.security.biometrics[type] 
          } 
        } 
      }
    }));
  };

  const handleReset = async () => {
    localStorage.clear();
    if (auth.currentUser) {
      await signOut(auth);
    }
    showToast('System reset complete. Data cleared.', 'error');
    setTimeout(() => window.location.reload(), 1000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-black uppercase tracking-tighter italic">OS Configuration</h2>
        <p className="text-xs opacity-50 font-bold uppercase tracking-widest">System preferences & security protocols</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Visual Identity */}
        <div className="space-y-6">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
            <Sun size={14} />
            Visual Identity
          </h3>
          <div className="grid grid-cols-3 gap-3">
            {(['light', 'dark', 'neon'] as const).map((t) => (
              <button
                key={t}
                onClick={() => toggleTheme(t)}
                className={cn(
                  "p-4 rounded-2xl border flex flex-col items-center gap-2 transition-all",
                  state.settings.theme === t 
                    ? "bg-green-500 text-black border-green-500" 
                    : "bg-white/5 border-white/10 hover:bg-white/10"
                )}
              >
                {t === 'light' && <Sun size={20} />}
                {t === 'dark' && <Moon size={20} />}
                {t === 'neon' && <Zap size={20} />}
                <span className="text-[10px] font-bold uppercase">{t}</span>
              </button>
            ))}
          </div>

          <div className="space-y-4 pt-4">
            <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
              <Globe size={14} />
              Regional
            </h3>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <span className="text-sm font-bold">Base Currency</span>
              <select 
                value={state.settings.currency}
                onChange={(e) => updateState(prev => ({ ...prev, settings: { ...prev.settings, currency: e.target.value } }))}
                className="bg-zinc-800 border border-white/10 rounded-lg px-3 py-1 text-xs font-bold outline-none"
              >
                <option value="$">USD ($)</option>
                <option value="€">EUR (€)</option>
                <option value="£">GBP (£)</option>
                <option value="₹">INR (₹)</option>
                <option value="¥">JPY (¥)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Security Protocols */}
        <div className="space-y-6">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2 pt-4">
            <Shield size={14} />
            Security Protocols
          </h3>
          <div className="space-y-3">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg">
                  <Calculator size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">Calculator Disguise</p>
                  <p className="text-[10px] opacity-50 uppercase font-bold">Fake app mode</p>
                </div>
              </div>
              <button 
                onClick={toggleFakeMode}
                className={cn(
                  "w-12 h-6 rounded-full p-1 transition-colors",
                  state.settings.security.fakeAppMode ? "bg-green-500" : "bg-zinc-800"
                )}
              >
                <div className={cn(
                  "w-4 h-4 bg-black rounded-full transition-transform",
                  state.settings.security.fakeAppMode ? "translate-x-6" : "translate-x-0"
                )} />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-500/20 text-red-400 rounded-lg">
                  <Eye size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">Decoy Mode</p>
                  <p className="text-[10px] opacity-50 uppercase font-bold">Show fake financial data</p>
                </div>
              </div>
              <button 
                onClick={toggleDecoyMode}
                className={cn(
                  "w-12 h-6 rounded-full p-1 transition-colors",
                  state.settings.security.decoyMode ? "bg-green-500" : "bg-zinc-800"
                )}
              >
                <div className={cn(
                  "w-4 h-4 bg-black rounded-full transition-transform",
                  state.settings.security.decoyMode ? "translate-x-6" : "translate-x-0"
                )} />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500/20 text-purple-400 rounded-lg">
                  <Fingerprint size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">Touch ID</p>
                  <p className="text-[10px] opacity-50 uppercase font-bold">Fingerprint authentication</p>
                </div>
              </div>
              <button 
                onClick={() => toggleBiometric('fingerprint')}
                className={cn(
                  "w-12 h-6 rounded-full p-1 transition-colors",
                  state.settings.security.biometrics.fingerprint ? "bg-green-500" : "bg-zinc-800"
                )}
              >
                <div className={cn(
                  "w-4 h-4 bg-black rounded-full transition-transform",
                  state.settings.security.biometrics.fingerprint ? "translate-x-6" : "translate-x-0"
                )} />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-yellow-500/20 text-yellow-400 rounded-lg">
                  <Scan size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">Face ID</p>
                  <p className="text-[10px] opacity-50 uppercase font-bold">Facial recognition</p>
                </div>
              </div>
              <button 
                onClick={() => toggleBiometric('faceId')}
                className={cn(
                  "w-12 h-6 rounded-full p-1 transition-colors",
                  state.settings.security.biometrics.faceId ? "bg-green-500" : "bg-zinc-800"
                )}
              >
                <div className={cn(
                  "w-4 h-4 bg-black rounded-full transition-transform",
                  state.settings.security.biometrics.faceId ? "translate-x-6" : "translate-x-0"
                )} />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-zinc-800 text-zinc-400 rounded-lg">
                  <Lock size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">Change Master PIN</p>
                  <p className="text-[10px] opacity-50 uppercase font-bold">Current: {state.settings.security.pin}</p>
                </div>
              </div>
              <button className="text-[10px] font-bold text-blue-400 uppercase">Update</button>
            </div>
          </div>
        </div>

        {/* Data Control */}
        <div className="lg:col-span-2 space-y-6 pt-4">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
            <Github size={14} />
            Developer Identity
          </h3>
          <div className="p-6 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-between group hover:bg-white/10 transition-all">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-zinc-800 flex items-center justify-center text-white">
                <Github size={24} />
              </div>
              <div>
                <p className="text-sm font-bold">{state.settings.githubProfile?.split('/').pop() || 'Not Connected'}</p>
                <p className="text-[10px] opacity-50 uppercase font-bold tracking-widest">Connected GitHub Profile</p>
              </div>
            </div>
            {state.settings.githubProfile && (
              <a 
                href={state.settings.githubProfile} 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-4 py-2 bg-white/10 rounded-xl text-[10px] font-bold uppercase hover:bg-white/20 transition-all"
              >
                View Profile
              </a>
            )}
          </div>
        </div>

        {/* Data Control */}
        <div className="lg:col-span-2 space-y-6 pt-4">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
            <Database size={14} />
            Data Control System
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="p-6 rounded-3xl bg-white/5 border border-white/10 flex flex-col items-center gap-3 hover:bg-white/10 transition-all">
              <Download size={24} className="text-blue-400" />
              <span className="text-[10px] font-bold uppercase">Export JSON</span>
            </button>
            <button className="p-6 rounded-3xl bg-white/5 border border-white/10 flex flex-col items-center gap-3 hover:bg-white/10 transition-all">
              <Upload size={24} className="text-green-400" />
              <span className="text-[10px] font-bold uppercase">Import Backup</span>
            </button>
            <button 
              onClick={handleReset}
              className="p-6 rounded-3xl bg-red-500/5 border border-red-500/20 flex flex-col items-center gap-3 hover:bg-red-500/10 transition-all"
            >
              <Trash2 size={24} className="text-red-500" />
              <span className="text-[10px] font-bold uppercase text-red-500">Factory Reset</span>
            </button>
          </div>
        </div>
      </div>
      
      <div className="pt-12 pb-8 text-center">
        <p className="text-[10px] font-bold uppercase opacity-20 tracking-[0.5em]">Infinity Finance OS v4.2.0-STABLE</p>
      </div>
    </div>
  );
}
