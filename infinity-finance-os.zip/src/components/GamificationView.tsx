import React from 'react';
import { motion } from 'motion/react';
import { 
  Trophy, 
  Zap, 
  Star, 
  Shield, 
  Target, 
  Flame, 
  Award,
  Lock,
  ChevronRight,
  TrendingUp,
  Trash2
} from 'lucide-react';
import { AppState } from '../types';
import { cn } from '../lib/utils';

interface GamificationViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export default function GamificationView({ state, updateState, showToast }: GamificationViewProps) {
  const nextLevelXp = 2000;
  const progress = (state.stats.xp % 1000) / 10;

  const handleClaimXp = () => {
    updateState(prev => ({
      ...prev,
      stats: {
        ...prev.stats,
        xp: prev.stats.xp + 50,
        level: Math.floor((prev.stats.xp + 50) / 1000) + 1
      }
    }));
    showToast('Claimed 50 XP!', 'success');
  };

  const handleStartChallenge = () => {
    const challenge = {
      id: 'impulse-demon-' + Date.now(),
      name: 'The Impulse Demon',
      description: '7-day no-spend challenge to defeat the Impulse Demon!',
      startDate: new Date().toISOString(),
      durationDays: 7,
      isActive: true
    };
    
    updateState(prev => ({
      ...prev,
      challenges: [...prev.challenges, challenge]
    }));
    showToast('Challenge Started: The Impulse Demon!', 'info');
  };

  const activeChallenge = state.challenges.find(c => c.isActive);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic">Discipline & Gamification</h2>
          <p className="text-xs opacity-50 font-bold uppercase tracking-widest">XP, levels, and financial boss battles</p>
        </div>
        <div className="flex items-center gap-2">
          {activeChallenge && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 px-4 py-2 rounded-xl">
              <Shield size={14} className="text-red-500" />
              <span className="text-[10px] font-black text-red-500 uppercase">Boss Battle Active</span>
            </div>
          )}
          <button 
            onClick={handleClaimXp}
            className="flex items-center gap-2 bg-green-500 text-black px-4 py-2 rounded-xl font-bold text-xs uppercase hover:bg-green-400 transition-colors"
          >
            <Zap size={14} fill="currentColor" />
            Claim XP
          </button>
          <div className="flex items-center gap-2 bg-orange-500/10 border border-orange-500/20 px-4 py-2 rounded-xl">
            <Flame size={18} className="text-orange-500" />
            <span className="text-sm font-black text-orange-500">{state.stats.streak} Day Streak</span>
          </div>
        </div>
      </div>

      {/* Level Progress */}
      <div className="p-8 rounded-[2rem] bg-zinc-900 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Trophy size={160} />
        </div>
        <div className="relative z-10 space-y-6">
          <div className="flex items-end gap-4">
            <h3 className="text-6xl font-black tracking-tighter italic">LVL {state.stats.level}</h3>
            <div className="mb-2 space-y-1">
              <p className="text-[10px] uppercase font-bold opacity-50">Financial Architect</p>
              <p className="text-xs font-bold text-green-400">{state.stats.xp} / {nextLevelXp} XP</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="w-full h-4 bg-white/5 rounded-full overflow-hidden border border-white/5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="h-full bg-gradient-to-r from-green-500 to-emerald-400"
              />
            </div>
            <div className="flex justify-between text-[10px] font-bold uppercase opacity-40">
              <span>Current: Novice Saver</span>
              <span>Next: Wealth Builder</span>
            </div>
          </div>
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
          <Award size={14} />
          Achievement System
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {state.achievements.map((achievement) => (
            <div 
              key={achievement.id}
              className={cn(
                "p-4 rounded-2xl border transition-all duration-300",
                achievement.isUnlocked 
                  ? "bg-green-500/5 border-green-500/20" 
                  : "bg-white/5 border-white/10 opacity-60"
              )}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={cn(
                  "p-2 rounded-xl",
                  achievement.isUnlocked ? "bg-green-500 text-black" : "bg-zinc-800 text-zinc-500"
                )}>
                  {achievement.isUnlocked ? <Star size={20} fill="currentColor" /> : <Lock size={20} />}
                </div>
                <div className="flex items-center gap-2">
                  {achievement.isUnlocked && (
                    <span className="text-[8px] font-black uppercase text-green-400">Unlocked</span>
                  )}
                  <button 
                    onClick={() => {
                      updateState(prev => ({
                        ...prev,
                        achievements: prev.achievements.filter(a => a.id !== achievement.id)
                      }));
                    }}
                    className="p-1 bg-red-500/10 text-red-500 rounded hover:bg-red-500/20 transition-colors"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
              <h4 className="text-sm font-black tracking-tight">{achievement.name}</h4>
              <p className="text-[10px] opacity-50 mt-1 leading-tight">{achievement.description}</p>
              
              {!achievement.isUnlocked && (
                <div className="mt-3 space-y-1">
                  <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-zinc-700" 
                      style={{ width: `${(achievement.progress / achievement.target) * 100}%` }}
                    />
                  </div>
                  <p className="text-[8px] font-bold opacity-30 text-right">
                    {achievement.progress} / {achievement.target}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Boss Battle Teaser */}
      <div className="p-8 rounded-[2rem] bg-red-600 text-white flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2">
            <Zap size={20} fill="currentColor" />
            <h3 className="text-xl font-black uppercase tracking-tighter italic">Financial Boss Battle</h3>
          </div>
          <p className="text-sm font-bold opacity-80">
            "The Impulse Demon" is draining your wealth. Complete a 7-day no-spend challenge to defeat him!
          </p>
        </div>
        <button 
          onClick={handleStartChallenge}
          disabled={!!activeChallenge}
          className={cn(
            "px-8 py-4 rounded-2xl font-black text-xs uppercase transition-colors flex items-center gap-2",
            activeChallenge 
              ? "bg-zinc-800 text-zinc-500 cursor-not-allowed" 
              : "bg-black text-white hover:bg-zinc-900"
          )}
        >
          {activeChallenge ? 'Challenge Active' : 'Start Challenge'}
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
}
