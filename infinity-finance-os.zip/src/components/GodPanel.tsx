import React from 'react';
import { motion } from 'motion/react';
import { 
  Database, 
  Zap, 
  ShieldAlert, 
  RefreshCw, 
  Trash2, 
  Unlock,
  Terminal,
  Cpu,
  Activity,
  Github,
  TrendingUp
} from 'lucide-react';
import { AppState } from '../types';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';

interface GodPanelProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export default function GodPanel({ state, updateState, showToast }: GodPanelProps) {
  const handleOverrideBalance = () => {
    updateState(prev => ({
      ...prev,
      transactions: [
        ...prev.transactions,
        { 
          id: 'god-' + Date.now(), 
          amount: 1000000, 
          type: 'income', 
          category: 'God Mode', 
          date: new Date().toISOString(), 
          tags: ['debug'], 
          isRecurring: false, 
          description: 'Divine Intervention' 
        }
      ]
    }));
    showToast(`Divine Intervention successful! ${state.settings.currency}1,000,000 added.`, 'success');
  };

  const handleUnlockAll = () => {
    updateState(prev => ({
      ...prev,
      achievements: prev.achievements.map(a => ({ ...a, isUnlocked: true, progress: a.target })),
      stats: { ...prev.stats, level: 99, xp: 99999 }
    }));
    showToast('Omnipotence achieved! All achievements unlocked and level maxed.', 'success');
  };

  const handleResetData = async () => {
    localStorage.removeItem('infinity_finance_os_state_v2');
    if (auth.currentUser) {
      await signOut(auth);
    }
    showToast('Final Judgment executed. System wiped.', 'error');
    setTimeout(() => window.location.reload(), 1000);
  };

  const handleSeedData = () => {
    updateState(prev => ({
      ...prev,
      transactions: [
        { id: '1', amount: 5000, type: 'income', category: 'Salary', date: new Date().toISOString(), tags: ['work'], isRecurring: true, description: 'Monthly Salary' },
        { id: '2', amount: 150, type: 'expense', category: 'Food', date: new Date().toISOString(), tags: ['lunch'], isRecurring: false, description: 'Lunch at Cafe' },
        { id: '3', amount: 50, type: 'expense', category: 'Subscription', date: new Date().toISOString(), tags: ['entertainment'], isRecurring: true, description: 'Netflix' },
      ],
      goals: [
        { id: '1', name: 'Emergency Fund', targetAmount: 10000, currentAmount: 2500, deadline: '2026-12-31', priority: 'high', subGoals: [] },
        { id: '2', name: 'New Laptop', targetAmount: 2000, currentAmount: 800, deadline: '2026-06-30', priority: 'medium', subGoals: [] },
      ],
      budgets: [
        { category: 'Food', limit: 500, spent: 150 },
        { category: 'Entertainment', limit: 200, spent: 50 },
        { category: 'Transport', limit: 300, spent: 0 },
      ],
      stats: {
        ...prev.stats,
        xp: 1250,
        level: 5,
        streak: 12,
        totalSaved: 3300,
        totalSpent: 200,
      }
    }));
    showToast('Genesis Protocol complete! System seeded with default data.', 'success');
  };

  const handleSimulateCrash = () => {
    updateState(prev => ({
      ...prev,
      transactions: [
        ...prev.transactions,
        { 
          id: 'crash-' + Date.now(), 
          amount: 50000, 
          type: 'expense', 
          category: 'Market Crash', 
          date: new Date().toISOString(), 
          tags: ['system', 'crash'], 
          isRecurring: false, 
          description: 'BLACK SWAN EVENT: Market Liquidation' 
        }
      ]
    }));
    showToast(`Black Swan event simulated! ${state.settings.currency}50,000 crash recorded.`, 'error');
  };

  const handleHyperGrowth = () => {
    updateState(prev => ({
      ...prev,
      transactions: [
        ...prev.transactions,
        { 
          id: 'growth-' + Date.now(), 
          amount: 250000, 
          type: 'income', 
          category: 'Hyper Growth', 
          date: new Date().toISOString(), 
          tags: ['system', 'growth'], 
          isRecurring: false, 
          description: 'QUANTUM SURGE: Portfolio Expansion' 
        }
      ]
    }));
    showToast(`Quantum Surge successful! ${state.settings.currency}250,000 growth simulated.`, 'success');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic text-red-500">God Developer Panel</h2>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-xs opacity-50 font-bold uppercase tracking-widest">Override logic & simulate extreme scenarios</p>
            {state.settings.githubProfile && (
              <div className="flex items-center gap-1 px-2 py-0.5 bg-white/5 border border-white/10 rounded-full">
                <Github size={10} className="text-white/50" />
                <span className="text-[8px] font-black uppercase text-white/50 tracking-tighter">
                  {state.settings.githubProfile.split('/').pop()}
                </span>
              </div>
            )}
          </div>
        </div>
        <div className="p-2 bg-red-500/10 border border-red-500/20 rounded-xl">
          <ShieldAlert size={20} className="text-red-500 animate-pulse" />
        </div>
      </div>

      <div className="p-6 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-zinc-800 flex items-center justify-center text-white">
            <Github size={24} />
          </div>
          <div>
            <p className="text-sm font-black uppercase italic tracking-tighter">Developer Kernel Linked</p>
            <p className="text-[10px] opacity-50 font-bold uppercase tracking-widest">bknithileshvar2009-droid</p>
          </div>
        </div>
        <a 
          href="https://github.com/bknithileshvar2009-droid" 
          target="_blank" 
          rel="noopener noreferrer"
          className="px-4 py-2 bg-red-500/20 border border-red-500/30 rounded-xl text-[10px] font-bold uppercase text-red-500 hover:bg-red-500/30 transition-all"
        >
          Access Repository
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <button 
          onClick={handleOverrideBalance}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-green-500/10 hover:border-green-500/50 transition-all text-left space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-green-500/20 text-green-500 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Zap size={20} fill="currentColor" />
          </div>
          <h3 className="text-sm font-black uppercase tracking-tight">Divine Intervention</h3>
          <p className="text-[10px] opacity-50 font-bold uppercase">Add {state.settings.currency}1,000,000 to balance</p>
        </button>

        <button 
          onClick={handleHyperGrowth}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-blue-500/10 hover:border-blue-500/50 transition-all text-left space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-500 flex items-center justify-center group-hover:scale-110 transition-transform">
            <TrendingUp size={20} />
          </div>
          <h3 className="text-sm font-black uppercase tracking-tight">Quantum Surge</h3>
          <p className="text-[10px] opacity-50 font-bold uppercase">Simulate +{state.settings.currency}250,000 growth</p>
        </button>

        <button 
          onClick={handleSimulateCrash}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-orange-500/10 hover:border-orange-500/50 transition-all text-left space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-500 flex items-center justify-center group-hover:scale-110 transition-transform">
            <ShieldAlert size={20} />
          </div>
          <h3 className="text-sm font-black uppercase tracking-tight">Black Swan</h3>
          <p className="text-[10px] opacity-50 font-bold uppercase">Simulate -{state.settings.currency}50,000 crash</p>
        </button>

        <button 
          onClick={handleUnlockAll}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-blue-500/10 hover:border-blue-500/50 transition-all text-left space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-500 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Unlock size={20} />
          </div>
          <h3 className="text-sm font-black uppercase tracking-tight">Omnipotence</h3>
          <p className="text-[10px] opacity-50 font-bold uppercase">Unlock all achievements & Max Level</p>
        </button>

        <button 
          onClick={handleSeedData}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-yellow-500/10 hover:border-yellow-500/50 transition-all text-left space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-yellow-500/20 text-yellow-500 flex items-center justify-center group-hover:scale-110 transition-transform">
            <RefreshCw size={20} />
          </div>
          <h3 className="text-sm font-black uppercase tracking-tight">Genesis Protocol</h3>
          <p className="text-[10px] opacity-50 font-bold uppercase">Seed system with default data</p>
        </button>

        <button 
          onClick={handleResetData}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-red-500/10 hover:border-red-500/50 transition-all text-left space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-red-500/20 text-red-500 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Trash2 size={20} />
          </div>
          <h3 className="text-sm font-black uppercase tracking-tight">Final Judgment</h3>
          <p className="text-[10px] opacity-50 font-bold uppercase">Wipe all local data</p>
        </button>
      </div>

      {/* Debug Console */}
      <div className="p-8 rounded-[2rem] bg-black border border-white/10 font-mono space-y-4">
        <div className="flex items-center gap-2 text-zinc-500 text-xs">
          <Terminal size={14} />
          <span>INFINITY_OS_DEBUG_CONSOLE v4.2.0</span>
        </div>
        <div className="space-y-1 text-[10px] text-green-500 opacity-80">
          <p>{`> Initializing financial kernel...`}</p>
          <p>{`> Loading behavioral tracking engine...`}</p>
          <p>{`> Security protocols: OMNI_ACTIVE`}</p>
          <p>{`> Current Session: ${Math.random().toString(36).substr(2, 16)}`}</p>
          <p className="animate-pulse">{`> Listening for divine commands...`}</p>
        </div>
      </div>

      {/* System Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
            <Cpu size={14} />
            Kernel Performance
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold uppercase opacity-40">State Size</span>
              <span className="text-xs font-bold">{(JSON.stringify(state).length / 1024).toFixed(2)} KB</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold uppercase opacity-40">Persistence Latency</span>
              <span className="text-xs font-bold">1.2ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold uppercase opacity-40">System Rule Count</span>
              <span className="text-xs font-bold">142 Active</span>
            </div>
          </div>
        </div>

        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
            <Activity size={14} />
            Behavioral Entropy
          </h3>
          <div className="h-24 flex items-end gap-1">
            {[40, 70, 45, 90, 65, 30, 85, 50, 60, 40, 75, 95].map((h, i) => (
              <motion.div 
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                className="flex-1 bg-green-500/20 border-t border-green-500/40"
              />
            ))}
          </div>
          <p className="text-[8px] uppercase font-bold text-center opacity-30">Real-time spending volatility index</p>
        </div>
      </div>
    </div>
  );
}
