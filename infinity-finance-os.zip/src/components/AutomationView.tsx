import React from 'react';
import { motion } from 'motion/react';
import { 
  Zap, 
  Repeat, 
  Play, 
  Pause, 
  Settings, 
  Plus,
  Bell,
  Wallet,
  ArrowRight,
  ShieldAlert,
  Trash2
} from 'lucide-react';
import { AppState } from '../types';
import { cn } from '../lib/utils';

interface AutomationViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

export default function AutomationView({ state, updateState }: AutomationViewProps) {
  const [showAddModal, setShowAddModal] = React.useState(false);
  const [newRule, setNewRule] = React.useState({ name: '', trigger: '', action: '' });

  const toggleRule = (id: string) => {
    updateState(prev => ({
      ...prev,
      automationRules: prev.automationRules.map(r => 
        r.id === id ? { ...r, active: !r.active } : r
      )
    }));
  };

  const handleAddRule = () => {
    if (!newRule.name || !newRule.trigger || !newRule.action) return;
    
    updateState(prev => ({
      ...prev,
      automationRules: [
        ...prev.automationRules,
        {
          id: Math.random().toString(36).substr(2, 9),
          ...newRule,
          active: true
        }
      ]
    }));
    
    setShowAddModal(false);
    setNewRule({ name: '', trigger: '', action: '' });
  };

  const recurringTransactions = state.transactions.filter(t => t.isRecurring);

  const toggleRiskTrigger = (key: keyof typeof state.settings.automation.riskTriggers) => {
    updateState(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        automation: {
          ...prev.settings.automation,
          riskTriggers: {
            ...prev.settings.automation.riskTriggers,
            [key]: !prev.settings.automation.riskTriggers[key]
          }
        }
      }
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic">Automation Engine</h2>
          <p className="text-xs opacity-50 font-bold uppercase tracking-widest">Rule-based triggers & scheduled actions</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-green-500 text-black p-3 rounded-xl hover:bg-green-400 transition-colors"
        >
          <Plus size={20} />
        </button>
      </div>

      {/* Active Automations */}
      <div className="grid grid-cols-1 gap-4">
        {state.automationRules.map((rule) => (
          <motion.div 
            key={rule.id}
            whileHover={{ x: 4 }}
            className="p-6 rounded-3xl bg-white/5 border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-6 group"
          >
            <div className="flex items-center gap-4">
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center",
                rule.active ? "bg-green-500/20 text-green-500" : "bg-zinc-800 text-zinc-600"
              )}>
                <Zap size={24} fill={rule.active ? "currentColor" : "none"} />
              </div>
              <div>
                <h3 className="text-lg font-black tracking-tight">{rule.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] uppercase font-bold opacity-40">IF {rule.trigger}</span>
                  <ArrowRight size={10} className="opacity-20" />
                  <span className="text-[10px] uppercase font-bold text-blue-400">THEN {rule.action}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex flex-col items-end">
                <span className="text-[10px] uppercase font-bold opacity-30">Last Triggered</span>
                <span className="text-xs font-bold">{rule.lastTriggered || 'Never'}</span>
              </div>
              <button 
                onClick={() => toggleRule(rule.id)}
                className={cn(
                  "p-3 rounded-xl transition-all",
                  rule.active ? "bg-green-500 text-black" : "bg-white/5 text-zinc-500"
                )}
              >
                {rule.active ? <Pause size={20} /> : <Play size={20} />}
              </button>
              <button 
                onClick={() => {
                  updateState(prev => ({
                    ...prev,
                    automationRules: prev.automationRules.filter(r => r.id !== rule.id)
                  }));
                }}
                className="p-3 bg-red-500/10 text-red-500 rounded-xl transition-all hover:bg-red-500/20"
                title="Delete Rule"
              >
                <Trash2 size={20} />
              </button>
              <button className="p-3 bg-white/5 rounded-xl opacity-0 group-hover:opacity-100 transition-all">
                <Settings size={20} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-zinc-900 border border-white/10 rounded-3xl p-6 w-full max-w-md space-y-4"
          >
            <h3 className="text-xl font-black uppercase tracking-tighter italic">New Automation Rule</h3>
            
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Rule Name</label>
              <input 
                type="text" 
                value={newRule.name}
                onChange={(e) => setNewRule(prev => ({ ...prev, name: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="e.g. Weekly Savings"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Trigger (IF)</label>
              <input 
                type="text" 
                value={newRule.trigger}
                onChange={(e) => setNewRule(prev => ({ ...prev, trigger: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="e.g. Income > ₹1000"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Action (THEN)</label>
              <input 
                type="text" 
                value={newRule.action}
                onChange={(e) => setNewRule(prev => ({ ...prev, action: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="e.g. Move ₹100 to Vault"
              />
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <button 
                onClick={() => setShowAddModal(false)}
                className="px-6 py-3 rounded-xl font-bold text-xs uppercase hover:bg-white/5 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleAddRule}
                className="px-6 py-3 bg-green-500 text-black rounded-xl font-bold text-xs uppercase hover:bg-green-400 transition-colors"
              >
                Create Rule
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Smart Triggers Config */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-8 rounded-[2rem] bg-gradient-to-br from-zinc-800 to-black border border-white/10 space-y-6">
          <div className="flex items-center gap-3">
            <Repeat size={24} className="text-blue-400" />
            <h3 className="text-xl font-black uppercase tracking-tighter italic">Recurring Logic</h3>
          </div>
          <div className="space-y-4">
            {recurringTransactions.length > 0 ? (
              recurringTransactions.map(t => (
                <div key={t.id} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 group">
                  <div>
                    <p className="text-xs font-bold">{t.description || t.category}</p>
                    <p className="text-[10px] opacity-50 uppercase font-bold">Recurring • {t.category}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-black">{state.settings.currency}{t.amount.toLocaleString()}</span>
                    <button 
                      onClick={() => {
                        updateState(prev => ({
                          ...prev,
                          transactions: prev.transactions.filter(tr => tr.id !== t.id)
                        }));
                      }}
                      className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-xs opacity-30 italic text-center py-4">No recurring logic detected...</p>
            )}
          </div>
          <button className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl text-xs font-bold uppercase hover:bg-white/10 transition-colors">
            Manage All Recurring
          </button>
        </div>

        <div className="p-8 rounded-[2rem] bg-zinc-900 border border-white/10 space-y-6">
          <div className="flex items-center gap-3">
            <ShieldAlert size={24} className="text-red-500" />
            <h3 className="text-xl font-black uppercase tracking-tighter italic">Risk Triggers</h3>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold opacity-70">Low Balance Alert</span>
              <button 
                onClick={() => toggleRiskTrigger('lowBalance')}
                className={cn(
                  "w-12 h-6 rounded-full p-1 flex transition-all",
                  state.settings.automation.riskTriggers.lowBalance ? "bg-green-500 justify-end" : "bg-zinc-800 justify-start"
                )}
              >
                <div className={cn("w-4 h-4 rounded-full", state.settings.automation.riskTriggers.lowBalance ? "bg-black" : "bg-zinc-600")} />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold opacity-70">Large Expense Warning</span>
              <button 
                onClick={() => toggleRiskTrigger('largeExpense')}
                className={cn(
                  "w-12 h-6 rounded-full p-1 flex transition-all",
                  state.settings.automation.riskTriggers.largeExpense ? "bg-green-500 justify-end" : "bg-zinc-800 justify-start"
                )}
              >
                <div className={cn("w-4 h-4 rounded-full", state.settings.automation.riskTriggers.largeExpense ? "bg-black" : "bg-zinc-600")} />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold opacity-70">Unusual Activity Lock</span>
              <button 
                onClick={() => toggleRiskTrigger('unusualActivity')}
                className={cn(
                  "w-12 h-6 rounded-full p-1 flex transition-all",
                  state.settings.automation.riskTriggers.unusualActivity ? "bg-green-500 justify-end" : "bg-zinc-800 justify-start"
                )}
              >
                <div className={cn("w-4 h-4 rounded-full", state.settings.automation.riskTriggers.unusualActivity ? "bg-black" : "bg-zinc-600")} />
              </button>
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20">
            <p className="text-[10px] font-bold text-red-400 leading-relaxed">
              "Risk triggers use behavioral mapping to detect anomalies in your spending patterns."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
