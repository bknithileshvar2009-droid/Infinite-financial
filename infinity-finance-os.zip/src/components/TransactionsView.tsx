import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Upload, 
  Trash2, 
  Tag,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  MoreVertical
} from 'lucide-react';
import { AppState, Transaction } from '../types';
import { cn } from '../lib/utils';

interface TransactionsViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export default function TransactionsView({ state, updateState, showToast }: TransactionsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTransaction, setNewTransaction] = useState<Partial<Transaction>>({
    type: 'expense',
    date: new Date().toISOString().split('T')[0],
    tags: [],
    isRecurring: false
  });

  const filteredTransactions = state.transactions.filter(t => 
    t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleAddTransaction = () => {
    if (!newTransaction.amount || !newTransaction.category) return;

    const transaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      amount: Number(newTransaction.amount),
      type: newTransaction.type as 'income' | 'expense',
      category: newTransaction.category,
      date: newTransaction.date || new Date().toISOString(),
      tags: newTransaction.tags || [],
      isRecurring: newTransaction.isRecurring || false,
      description: newTransaction.description || '',
    };

    // Risk Triggers
    if (transaction.type === 'expense') {
      const currentBalance = state.transactions.reduce((acc, t) => 
        t.type === 'income' ? acc + t.amount : acc - t.amount, 0
      );
      const newBalance = currentBalance - transaction.amount;

      if (state.settings.automation.riskTriggers.lowBalance && newBalance < 500) {
        showToast(`RISK ALERT: Low balance detected! Current balance: ${state.settings.currency}${newBalance}`, 'error');
      }
      if (state.settings.automation.riskTriggers.largeExpense && transaction.amount > 1000) {
        showToast(`RISK ALERT: Large expense detected! Amount: ${state.settings.currency}${transaction.amount}`, 'error');
      }
    }

    updateState(prev => ({
      ...prev,
      transactions: [transaction, ...prev.transactions],
      stats: {
        ...prev.stats,
        totalSpent: transaction.type === 'expense' ? prev.stats.totalSpent + transaction.amount : prev.stats.totalSpent,
        xp: prev.stats.xp + 10
      }
    }));

    showToast('Transaction recorded successfully.', 'success');
    setShowAddModal(false);
    setNewTransaction({ type: 'expense', date: new Date().toISOString().split('T')[0], tags: [], isRecurring: false });
  };

  const handleDelete = (id: string) => {
    updateState(prev => ({
      ...prev,
      transactions: prev.transactions.filter(t => t.id !== id)
    }));
    showToast('Transaction deleted.', 'info');
  };

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic">Transaction Engine</h2>
          <p className="text-xs opacity-50 font-bold uppercase tracking-widest">Full CRUD Control & Tagging</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex-1 md:flex-none bg-green-500 text-black px-4 py-2 rounded-xl font-bold text-xs uppercase flex items-center justify-center gap-2 hover:bg-green-400 transition-colors"
          >
            <Plus size={16} />
            Add Entry
          </button>
          <button className="p-2 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors">
            <Download size={18} />
          </button>
          <button className="p-2 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors">
            <Upload size={18} />
          </button>
          <button 
            onClick={() => {
              updateState(prev => ({
                ...prev,
                transactions: [],
                stats: { ...prev.stats, totalSpent: 0, totalSaved: 0 }
              }));
            }}
            className="p-2 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl hover:bg-red-500/20 transition-colors"
            title="Clear All History"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30" size={16} />
          <input 
            type="text" 
            placeholder="Search transactions, tags, categories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-xs font-bold outline-none focus:border-green-500/50 transition-colors"
          />
        </div>
        <button className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors">
          <Filter size={18} />
        </button>
      </div>

      {/* Transactions List */}
      <div className="space-y-2">
        {filteredTransactions.map((t) => (
          <motion.div 
            layout
            key={t.id}
            className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between group hover:bg-white/[0.07] transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center",
                t.type === 'income' ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
              )}>
                {t.type === 'income' ? <ArrowUpRight size={20} /> : <ArrowDownRight size={20} />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-bold">{t.description || t.category}</p>
                  {t.description && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        updateState(prev => ({
                          ...prev,
                          transactions: prev.transactions.map(tr => tr.id === t.id ? { ...tr, description: '' } : tr)
                        }));
                      }}
                      className="p-1 hover:bg-red-500/10 text-red-500/50 hover:text-red-500 rounded transition-colors"
                      title="Delete Comment"
                    >
                      <Trash2 size={10} />
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[10px] uppercase font-bold opacity-40">{t.category}</span>
                  <span className="text-[10px] opacity-20">•</span>
                  <span className="text-[10px] uppercase font-bold opacity-40">{new Date(t.date).toLocaleDateString()}</span>
                  {t.tags.map(tag => (
                    <span key={tag} className="text-[8px] px-1.5 py-0.5 bg-white/5 rounded border border-white/10 opacity-60">#{tag}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className={cn(
                  "text-sm font-black tracking-tight",
                  t.type === 'income' ? "text-green-400" : "text-red-400"
                )}>
                  {t.type === 'income' ? '+' : '-'}{state.settings.currency}{t.amount.toLocaleString()}
                </p>
                {t.isRecurring && (
                  <p className="text-[8px] uppercase font-bold text-blue-400">Recurring</p>
                )}
              </div>
              <button 
                onClick={() => handleDelete(t.id)}
                className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-zinc-900 border border-white/10 rounded-3xl p-6 w-full max-w-md space-y-4"
          >
            <h3 className="text-xl font-black uppercase tracking-tighter italic">New Transaction</h3>
            
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => setNewTransaction(prev => ({ ...prev, type: 'income' }))}
                className={cn(
                  "py-3 rounded-xl font-bold text-xs uppercase border transition-all",
                  newTransaction.type === 'income' ? "bg-green-500 text-black border-green-500" : "bg-white/5 border-white/10 opacity-50"
                )}
              >
                Income
              </button>
              <button 
                onClick={() => setNewTransaction(prev => ({ ...prev, type: 'expense' }))}
                className={cn(
                  "py-3 rounded-xl font-bold text-xs uppercase border transition-all",
                  newTransaction.type === 'expense' ? "bg-red-500 text-black border-red-500" : "bg-white/5 border-white/10 opacity-50"
                )}
              >
                Expense
              </button>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Amount</label>
              <input 
                type="number" 
                value={newTransaction.amount || ''}
                onChange={(e) => setNewTransaction(prev => ({ ...prev, amount: Number(e.target.value) }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="0.00"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Category</label>
              <input 
                type="text" 
                value={newTransaction.category || ''}
                onChange={(e) => setNewTransaction(prev => ({ ...prev, category: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="e.g. Food, Rent, Salary"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Description</label>
              <input 
                type="text" 
                value={newTransaction.description || ''}
                onChange={(e) => setNewTransaction(prev => ({ ...prev, description: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="What was this for?"
              />
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <button 
                onClick={() => setShowAddModal(false)}
                className="px-6 py-3 rounded-xl font-bold text-xs uppercase hover:bg-white/5 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleAddTransaction}
                className="px-6 py-3 bg-green-500 text-black rounded-xl font-bold text-xs uppercase hover:bg-green-400 transition-colors"
              >
                Save Entry
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
