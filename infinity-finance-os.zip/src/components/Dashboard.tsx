import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Activity, 
  Zap, 
  Shield, 
  Target,
  ArrowUpRight,
  ArrowDownRight,
  AlertCircle,
  Trophy,
  Trash2,
  CheckCircle2
} from 'lucide-react';
import { AppState } from '../types';
import { cn } from '../lib/utils';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

interface DashboardProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
  setView: (view: string) => void;
}

export default function Dashboard({ state, updateState, setView }: DashboardProps) {
  const totalBalance = state.transactions.reduce((acc, t) => 
    t.type === 'income' ? acc + t.amount : acc - t.amount, 0
  );

  const monthlyIncome = state.incomeSources.reduce((acc, s) => acc + s.amount, 0);
  const monthlyExpenses = state.transactions
    .filter(t => t.type === 'expense' && new Date(t.date).getMonth() === new Date().getMonth())
    .reduce((acc, t) => acc + t.amount, 0);

  const healthIndex = Math.min(100, Math.max(0, 
    state.stats.totalSaved > 0 ? (state.stats.totalSaved / (state.stats.totalSpent + state.stats.totalSaved)) * 100 : 0
  ));

  const chartData = useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return {
        name: days[d.getDay()],
        date: d.toISOString().split('T')[0],
        value: 0
      };
    });

    state.transactions.forEach(t => {
      const tDate = t.date.split('T')[0];
      const day = last7Days.find(d => d.date === tDate);
      if (day) {
        day.value += t.type === 'income' ? t.amount : -t.amount;
      }
    });

    // Cumulative value
    let runningTotal = totalBalance;
    // This is a bit complex for a simple dashboard, let's just show daily net
    return last7Days;
  }, [state.transactions, totalBalance]);

  const growthRate = useMemo(() => {
    if (state.transactions.length < 2) return 0;
    const now = new Date();
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
    
    const currentMonthNet = state.transactions
      .filter(t => new Date(t.date) >= lastMonth)
      .reduce((acc, t) => t.type === 'income' ? acc + t.amount : acc - t.amount, 0);
      
    const previousMonthNet = state.transactions
      .filter(t => new Date(t.date) < lastMonth)
      .reduce((acc, t) => t.type === 'income' ? acc + t.amount : acc - t.amount, 0);
      
    if (previousMonthNet === 0) return currentMonthNet > 0 ? 100 : 0;
    return ((currentMonthNet - previousMonthNet) / Math.abs(previousMonthNet)) * 100;
  }, [state.transactions]);

  return (
    <div className="space-y-6">
      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 flex flex-col justify-between h-48 relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-40 transition-opacity">
            <Wallet size={80} />
          </div>
          <div>
            <span className="text-xs font-bold uppercase tracking-widest opacity-50">Total Net Worth</span>
            <h2 className="text-4xl font-black mt-1 tracking-tighter">
              {state.settings.currency}{totalBalance.toLocaleString()}
            </h2>
          </div>
          <div className={cn(
            "flex items-center gap-2 text-sm font-bold",
            growthRate >= 0 ? "text-green-400" : "text-red-400"
          )}>
            {growthRate >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            <span>{growthRate >= 0 ? '+' : ''}{growthRate.toFixed(1)}% this month</span>
          </div>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 flex flex-col justify-between h-48"
        >
          <div>
            <span className="text-xs font-bold uppercase tracking-widest opacity-50">Financial Health</span>
            <div className="flex items-end gap-2 mt-1">
              <h2 className="text-4xl font-black tracking-tighter">{healthIndex.toFixed(0)}</h2>
              <span className="text-sm font-bold opacity-50 mb-1">/ 100</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${healthIndex}%` }}
                className="h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"
              />
            </div>
            <p className="text-[10px] uppercase font-bold opacity-50">Wealth growth speed: Optimal</p>
          </div>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="p-6 rounded-3xl bg-white/5 border border-white/10 flex flex-col justify-between h-48"
        >
          <div className="flex justify-between items-start">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest opacity-50">Active Streak</span>
              <h2 className="text-4xl font-black mt-1 tracking-tighter">{state.stats.streak} Days</h2>
            </div>
            <div className="p-2 bg-orange-500/20 text-orange-500 rounded-lg">
              <Zap size={20} fill="currentColor" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              {[1,2,3,4,5].map(i => (
                <div key={i} className="w-6 h-6 rounded-full bg-white/10 border border-black flex items-center justify-center text-[8px] font-bold">
                  {i}
                </div>
              ))}
            </div>
            <span className="text-[10px] font-bold uppercase opacity-50">
              +{state.achievements.filter(a => !a.isUnlocked).length} achievements pending
            </span>
          </div>
        </motion.div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-sm font-bold uppercase tracking-widest flex items-center gap-2">
                <Activity size={16} className="text-green-400" />
                Wealth Growth Curve
              </h3>
              <select className="bg-white/5 border border-white/10 rounded-lg text-[10px] font-bold uppercase px-2 py-1 outline-none">
                <option>Last 7 Days</option>
                <option>Last 30 Days</option>
                <option>Year to Date</option>
              </select>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4ade80" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#4ade80" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    stroke="#ffffff40" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <YAxis 
                    stroke="#ffffff40" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(value) => `${state.settings.currency}${value}`}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#000', border: '1px solid #ffffff20', borderRadius: '12px', fontSize: '10px' }}
                    itemStyle={{ color: '#4ade80' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#4ade80" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorValue)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
              <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 mb-4">Money Leak Finder</h3>
            <div className="space-y-4">
              {state.transactions.filter(t => t.type === 'expense' && t.isRecurring).length > 0 ? (
                state.transactions.filter(t => t.type === 'expense' && t.isRecurring).slice(0, 2).map(t => (
                  <div key={t.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-red-500/20 text-red-500 rounded-lg">
                        <AlertCircle size={16} />
                      </div>
                      <div>
                        <p className="text-xs font-bold">{t.category}</p>
                        <p className="text-[10px] opacity-50">Recurring Expense</p>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-red-400">-{state.settings.currency}{t.amount}</span>
                  </div>
                ))
              ) : (
                <div className="flex items-center gap-3 opacity-30">
                  <div className="p-2 bg-white/10 rounded-lg">
                    <CheckCircle2 size={16} />
                  </div>
                  <p className="text-xs font-bold">No leaks detected</p>
                </div>
              )}
            </div>
            </div>

          <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
            <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 mb-4">System Intelligence</h3>
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-black text-green-500 uppercase">Auto-Collector</span>
                  <span className="text-[8px] opacity-30 uppercase font-black tracking-tighter">Running</span>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] items-center gap-1 flex">
                    <CheckCircle2 size={10} className="text-green-500" />
                    Background sync active
                  </p>
                  <p className="text-[10px] items-center gap-1 flex">
                    <CheckCircle2 size={10} className="text-green-500" />
                    Recurring logic optimized
                  </p>
                  <p className="text-[10px] items-center gap-1 flex">
                    <CheckCircle2 size={10} className="text-green-500" />
                    Cloud persistence: OK
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
                <p className="text-[10px] font-bold text-blue-400 leading-relaxed italic">
                  "System automatically collects and syncs your financial data every {state.settings.automation.autoSaveRule}% of interaction."
                </p>
              </div>
            </div>
          </div>
          </div>
        </div>

        {/* Sidebar Section */}
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest opacity-50">Active Goals</h3>
              <button 
                onClick={() => setView('goals')}
                className="text-[10px] font-bold text-green-400 uppercase hover:underline"
              >
                View All
              </button>
            </div>
            <div className="space-y-4">
              {state.goals.map(goal => (
                <div key={goal.id} className="space-y-2 group relative">
                  <div className="flex justify-between items-end">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-bold">{goal.name}</p>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          updateState(prev => ({
                            ...prev,
                            goals: prev.goals.filter(g => g.id !== goal.id)
                          }));
                        }}
                        className="p-1 text-red-500 hover:bg-red-500/10 rounded transition-all"
                      >
                        <Trash2 size={10} />
                      </button>
                    </div>
                    <p className="text-[10px] opacity-50">{Math.round((goal.currentAmount / goal.targetAmount) * 100)}%</p>
                  </div>
                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(goal.currentAmount / goal.targetAmount) * 100}%` }}
                      className="h-full bg-green-500"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-white/5 border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest opacity-50">Recent Transactions</h3>
              <button 
                onClick={() => setView('transactions')}
                className="text-[10px] font-bold text-green-400 uppercase hover:underline"
              >
                View All
              </button>
            </div>
            <div className="space-y-4">
              {state.transactions.slice(0, 4).map(t => (
                <div key={t.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "p-2 rounded-lg",
                      t.type === 'income' ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
                    )}>
                      {t.type === 'income' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                    </div>
                    <div>
                      <p className="text-xs font-bold">{t.category}</p>
                      <p className="text-[10px] opacity-50">{new Date(t.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <span className={cn(
                    "text-xs font-bold",
                    t.type === 'income' ? "text-green-400" : "text-red-400"
                  )}>
                    {t.type === 'income' ? '+' : '-'}{state.settings.currency}{t.amount}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-gradient-to-br from-green-500 to-emerald-700 text-black">
            <div className="flex items-center gap-2 mb-2">
              <Trophy size={20} />
              <h3 className="text-sm font-black uppercase tracking-tighter">Pro Tip</h3>
            </div>
            <p className="text-xs font-bold leading-tight">
              Switch to 'Stealth Mode' in settings to hide sensitive data from prying eyes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
