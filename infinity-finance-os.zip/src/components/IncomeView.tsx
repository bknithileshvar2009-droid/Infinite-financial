import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowUpRight, 
  TrendingUp, 
  Zap, 
  Plus, 
  Briefcase, 
  Globe, 
  Cpu,
  PieChart,
  BarChart
} from 'lucide-react';
import { AppState, IncomeSource } from '../types';

interface IncomeViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
}

export default function IncomeView({ state, updateState }: IncomeViewProps) {
  const activeIncome = state.incomeSources.filter(s => s.type === 'active').reduce((acc, s) => acc + s.amount, 0);
  const passiveIncome = state.incomeSources.filter(s => s.type === 'passive').reduce((acc, s) => acc + s.amount, 0);
  const totalIncome = activeIncome + passiveIncome;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic">Income Matrix</h2>
          <p className="text-xs opacity-50 font-bold uppercase tracking-widest">Multi-source tracking & system engine</p>
        </div>
        <button className="bg-green-500 text-black p-3 rounded-xl hover:bg-green-400 transition-colors">
          <Plus size={20} />
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-2">
          <p className="text-[10px] uppercase font-bold opacity-50">Total Monthly</p>
          <h3 className="text-3xl font-black tracking-tighter">{state.settings.currency}{totalIncome.toLocaleString()}</h3>
          <div className="flex items-center gap-1 text-green-400 text-[10px] font-bold">
            <TrendingUp size={12} />
            <span>+5.2% vs last month</span>
          </div>
        </div>
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-2">
          <p className="text-[10px] uppercase font-bold opacity-50">Active Income</p>
          <h3 className="text-3xl font-black tracking-tighter text-blue-400">{state.settings.currency}{activeIncome.toLocaleString()}</h3>
          <p className="text-[10px] font-bold opacity-30 uppercase">Main Job + Freelance</p>
        </div>
        <div className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-2">
          <p className="text-[10px] uppercase font-bold opacity-50">Passive Income</p>
          <h3 className="text-3xl font-black tracking-tighter text-purple-400">{state.settings.currency}{passiveIncome.toLocaleString()}</h3>
          <p className="text-[10px] font-bold opacity-30 uppercase">Dividends + Rentals</p>
        </div>
      </div>

      {/* Income Sources List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
            <Briefcase size={14} />
            Active Sources
          </h3>
          {state.incomeSources.filter(s => s.type === 'active').map(source => (
            <div key={source.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 text-blue-500 rounded-lg">
                  <Globe size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">{source.name}</p>
                  <p className="text-[10px] opacity-50 uppercase font-bold">{source.frequency}</p>
                </div>
              </div>
              <span className="text-sm font-black text-blue-400">{state.settings.currency}{source.amount.toLocaleString()}</span>
            </div>
          ))}
        </div>

        <div className="space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest opacity-50 flex items-center gap-2">
            <Cpu size={14} />
            Passive Sources
          </h3>
          {state.incomeSources.filter(s => s.type === 'passive').map(source => (
            <div key={source.id} className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500/20 text-purple-500 rounded-lg">
                  <Zap size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">{source.name}</p>
                  <p className="text-[10px] opacity-50 uppercase font-bold">{source.frequency}</p>
                </div>
              </div>
              <span className="text-sm font-black text-purple-400">{state.settings.currency}{source.amount.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Growth Prediction */}
      <div className="p-8 rounded-[2rem] bg-zinc-900 border border-white/10 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp size={24} className="text-green-400" />
            <h3 className="text-xl font-black uppercase tracking-tighter">Income Growth Tracking</h3>
          </div>
          <span className="px-3 py-1 bg-green-500/10 text-green-400 text-[10px] font-bold rounded-full border border-green-500/20 uppercase">System Active</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <p className="text-xs font-medium opacity-70 leading-relaxed">
              Based on your current income mapping, the system tracks your growth potential. Keep updating your sources for more accurate projections.
            </p>
            <div className="flex items-center gap-4">
              <div className="flex-1 h-2 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-green-500 w-[65%]" />
              </div>
              <span className="text-[10px] font-bold opacity-50">65% Confidence</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex flex-col justify-center gap-1">
              <p className="text-[8px] uppercase font-bold opacity-50">Projected 2027</p>
              <p className="text-lg font-black text-green-400">{state.settings.currency}84,500</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex flex-col justify-center gap-1">
              <p className="text-[8px] uppercase font-bold opacity-50">Passive Goal</p>
              <p className="text-lg font-black text-purple-400">{state.settings.currency}1,200/mo</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
