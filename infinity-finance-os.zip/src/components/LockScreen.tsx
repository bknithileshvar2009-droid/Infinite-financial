import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Shield, Fingerprint, AlertCircle, Eye, EyeOff, Scan } from 'lucide-react';

interface LockScreenProps {
  pin: string;
  onUnlock: () => void;
  theme: string;
  biometrics?: {
    fingerprint: boolean;
    faceId: boolean;
  };
}

export default function LockScreen({ pin, onUnlock, theme, biometrics }: LockScreenProps) {
  const [input, setInput] = useState('');
  const [error, setError] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [isAuthenticating, setIsAuthenticating] = useState<null | 'fingerprint' | 'faceid'>(null);

  const handleBiometric = (type: 'fingerprint' | 'faceid') => {
    setIsAuthenticating(type);
    // Simulate biometric scan
    setTimeout(() => {
      setIsAuthenticating(null);
      onUnlock();
    }, 1500);
  };

  useEffect(() => {
    console.log("[Security] Expected PIN:", pin);
    console.log("[Security] Fallback PIN: 9002");
  }, [pin]);

  const handleNumber = (num: string) => {
    if (error || input.length >= 4) return;

    const newInput = input + num;
    setInput(newInput);
    
    if (window.navigator.vibrate) {
      window.navigator.vibrate(10);
    }

    if (newInput.length === 4) {
      // Robust comparison: stringify and trim
      const targetPin = String(pin || '9002').trim();
      const enteredPin = newInput.trim();

      if (enteredPin === targetPin) {
        onUnlock();
      } else {
        setError(true);
        setAttempts(prev => prev + 1);
        setTimeout(() => {
          setInput('');
          setError(false);
        }, 600);
      }
    }
  };

  const handleBackspace = () => {
    setInput(prev => prev.slice(0, -1));
  };

  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center p-6 z-[200]">
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-center space-y-8 w-full max-w-xs"
      >
        <div className="flex flex-col items-center gap-4">
          <motion.div 
            animate={error ? { x: [-10, 10, -10, 10, 0] } : {}}
            className={`w-20 h-20 rounded-3xl flex items-center justify-center border-2 transition-colors ${
              error ? 'border-red-500 text-red-500 bg-red-500/10' : 'border-green-500/50 text-green-500 bg-green-500/10'
            }`}
          >
            <Lock size={32} />
          </motion.div>
          <div className="space-y-1">
            <h1 className="text-2xl font-black uppercase tracking-tighter italic text-white">Infinity OS</h1>
            <p className="text-[10px] uppercase font-bold tracking-[0.2em] text-zinc-500">Omni Security Active</p>
          </div>
        </div>

        {/* PIN Display */}
        <div className="flex justify-center gap-4">
          {[0, 1, 2, 3].map((i) => (
            <div 
              key={i}
              className={`w-10 h-10 rounded-xl border-2 flex items-center justify-center transition-all duration-300 ${
                input.length > i 
                  ? 'bg-green-500/20 border-green-500 scale-110' 
                  : 'border-zinc-800'
              }`}
            >
              {showPin && input[i] ? (
                <span className="text-green-500 font-black text-lg">{input[i]}</span>
              ) : input.length > i ? (
                <div className="w-2 h-2 rounded-full bg-green-500" />
              ) : null}
            </div>
          ))}
        </div>

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-4">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              onClick={() => handleNumber(num)}
              className="w-16 h-16 rounded-2xl bg-zinc-900/50 border border-white/5 text-xl font-bold text-white flex items-center justify-center hover:bg-zinc-800 transition-colors active:scale-90"
            >
              {num}
            </button>
          ))}
          <button 
            onClick={() => setShowPin(!showPin)}
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-zinc-500 hover:text-white transition-colors"
          >
            {showPin ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
          <button
            onClick={() => handleNumber('0')}
            className="w-16 h-16 rounded-2xl bg-zinc-900/50 border border-white/5 text-xl font-bold text-white flex items-center justify-center hover:bg-zinc-800 transition-colors active:scale-90"
          >
            0
          </button>
          <button
            onClick={handleBackspace}
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-zinc-500 hover:text-white transition-colors"
          >
            <Fingerprint size={24} />
          </button>
        </div>

        {/* Biometric Quick Access */}
        {(biometrics?.fingerprint || biometrics?.faceId) && (
          <div className="flex items-center justify-center gap-8 pt-4">
            {biometrics.faceId && (
              <button 
                onClick={() => handleBiometric('faceid')}
                className="flex flex-col items-center gap-2 group"
              >
                <div className="w-12 h-12 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center text-zinc-500 group-hover:text-green-500 group-hover:border-green-500/50 transition-all">
                  <Scan size={24} />
                </div>
                <span className="text-[8px] uppercase font-bold tracking-widest opacity-40 group-hover:opacity-100">Face ID</span>
              </button>
            )}
            {biometrics.fingerprint && (
              <button 
                onClick={() => handleBiometric('fingerprint')}
                className="flex flex-col items-center gap-2 group"
              >
                <div className="w-12 h-12 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center text-zinc-500 group-hover:text-green-500 group-hover:border-green-500/50 transition-all">
                  <Fingerprint size={24} />
                </div>
                <span className="text-[8px] uppercase font-bold tracking-widest opacity-40 group-hover:opacity-100">Touch ID</span>
              </button>
            )}
          </div>
        )}

        {/* Biometric Overlay */}
        <AnimatePresence>
          {isAuthenticating && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 backdrop-blur-xl z-[300] flex flex-col items-center justify-center gap-8"
            >
              <div className="relative">
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-32 h-32 rounded-full bg-green-500/10 border-2 border-green-500 flex items-center justify-center text-green-500"
                >
                  {isAuthenticating === 'faceid' ? <Scan size={64} /> : <Fingerprint size={64} />}
                </motion.div>
                <motion.div 
                  initial={{ top: 0 }}
                  animate={{ top: '100%' }}
                  transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                  className="absolute left-0 right-0 h-1 bg-green-500 shadow-[0_0_15px_rgba(34,197,94,0.8)]"
                />
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-xl font-black uppercase italic tracking-tighter text-white">
                  {isAuthenticating === 'faceid' ? 'Scanning Face...' : 'Scanning Fingerprint...'}
                </h3>
                <p className="text-[10px] uppercase font-bold tracking-[0.2em] text-green-500 animate-pulse">
                  Verifying Identity
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {attempts >= 3 && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-center gap-2 text-red-500 text-[10px] font-bold uppercase">
              <AlertCircle size={12} />
              <span>Intruder Detection Active</span>
            </div>
            <button 
              onClick={onUnlock}
              className="w-full py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-bold uppercase hover:bg-red-500/20 transition-all"
            >
              Emergency Bypass (Dev Mode)
            </button>
          </motion.div>
        )}

        <div className="pt-8 space-y-4">
          <p className="text-[10px] uppercase font-bold text-zinc-600 tracking-widest">Default PIN: 9002</p>
          <div className="flex flex-col gap-2">
            <button 
              onClick={onUnlock}
              className="text-[9px] uppercase font-black text-green-500/50 hover:text-green-400 transition-colors tracking-tighter"
            >
              Force Unlock (Debug Mode)
            </button>
            <button 
              onClick={() => {
                if (confirm("This will wipe all local data and reset the PIN to 9002. Continue?")) {
                  localStorage.clear();
                  window.location.reload();
                }
              }}
              className="text-[9px] uppercase font-black text-zinc-800 hover:text-red-500 transition-colors tracking-tighter"
            >
              Emergency System Reset
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
