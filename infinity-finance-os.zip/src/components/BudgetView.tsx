import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Shield, 
  AlertCircle, 
  CheckCircle2, 
  TrendingDown, 
  Zap,
  Lock,
  Unlock,
  Settings,
  Plus,
  Trash2
} from 'lucide-react';
import { AppState, Budget } from '../types';
import { cn } from '../lib/utils';

interface BudgetViewProps {
  state: AppState;
  updateState: (updater: (prev: AppState) => AppState) => void;
  setView?: (view: string) => void;
}

export default function BudgetView({ state, updateState, setView }: BudgetViewProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newBudget, setNewBudget] = useState<Partial<Budget>>({
    category: '',
    limit: 0,
    spent: 0
  });

  const totalBudget = state.budgets.reduce((acc, b) => acc + b.limit, 0);
  const totalSpent = state.budgets.reduce((acc, b) => acc + b.spent, 0);
  const budgetEfficiency = totalBudget > 0 ? Math.round(((totalBudget - totalSpent) / totalBudget) * 100) : 0;

  const handleAddBudget = () => {
    if (!newBudget.category || !newBudget.limit) return;

    updateState(prev => ({
      ...prev,
      budgets: [...prev.budgets, { 
        category: newBudget.category!, 
        limit: Number(newBudget.limit), 
        spent: 0 
      }]
    }));

    setShowAddModal(false);
    setNewBudget({ category: '', limit: 0, spent: 0 });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tighter italic">Budget Control</h2>
          <p className="text-xs opacity-50 font-bold uppercase tracking-widest">Set limits & real-time overspend blockers</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowAddModal(true)}
            className="bg-green-500 text-black p-3 rounded-xl hover:bg-green-400 transition-colors"
          >
            <Plus size={20} />
          </button>
          <button 
            onClick={() => setView?.('automation')}
            className="p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors"
          >
            <Settings size={20} />
          </button>
        </div>
      </div>

      {/* Efficiency Score */}
      <div className="p-8 rounded-[2rem] bg-zinc-900 border border-white/10 flex flex-col md:flex-row items-center gap-8">
        <div className="relative w-32 h-32 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="58"
              fill="none"
              stroke="currentColor"
              strokeWidth="12"
              className="text-white/5"
            />
            <motion.circle
              cx="64"
              cy="64"
              r="58"
              fill="none"
              stroke="currentColor"
              strokeWidth="12"
              strokeDasharray={364}
              initial={{ strokeDashoffset: 364 }}
              animate={{ strokeDashoffset: 364 - (364 * budgetEfficiency) / 100 }}
              className="text-green-500"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-black">{budgetEfficiency}%</span>
            <span className="text-[8px] uppercase font-bold opacity-50">Efficiency</span>
          </div>
        </div>
        <div className="flex-1 space-y-2 text-center md:text-left">
          <h3 className="text-xl font-black uppercase tracking-tighter">Budget Optimization Active</h3>
          <p className="text-sm opacity-60 leading-relaxed">
            Your spending efficiency is {budgetEfficiency > 70 ? 'excellent' : 'needs attention'}. The system automatically monitors your behavior to help you stay on track.
          </p>
          <div className="flex flex-wrap justify-center md:justify-start gap-2 pt-2">
            <span className="px-3 py-1 bg-green-500/10 text-green-400 text-[10px] font-bold rounded-full border border-green-500/20 uppercase">Hard Stop On</span>
            <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[10px] font-bold rounded-full border border-blue-500/20 uppercase">Dynamic Adjust</span>
          </div>
        </div>
      </div>

      {/* Category Limits */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {state.budgets.map((budget) => {
          const progress = (budget.spent / budget.limit) * 100;
          const isOver = progress > 100;

          return (
            <motion.div 
              key={budget.category}
              whileHover={{ scale: 1.01 }}
              className="p-6 rounded-3xl bg-white/5 border border-white/10 space-y-4"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "p-2 rounded-lg",
                    isOver ? "bg-red-500/20 text-red-500" : "bg-green-500/20 text-green-500"
                  )}>
                    {isOver ? <AlertCircle size={18} /> : <CheckCircle2 size={18} />}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold">{budget.category}</h4>
                    <p className="text-[10px] opacity-50 uppercase font-bold">Monthly Limit</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-black">{state.settings.currency}{budget.spent.toLocaleString()} / {state.settings.currency}{budget.limit.toLocaleString()}</p>
                  <p className={cn(
                    "text-[10px] font-bold uppercase",
                    isOver ? "text-red-400" : "text-green-400"
                  )}>
                    {isOver ? `Over by ${state.settings.currency}${budget.spent - budget.limit}` : `${Math.round(100 - progress)}% remaining`}
                  </p>
                </div>
              </div>

              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(100, progress)}%` }}
                  className={cn(
                    "h-full",
                    isOver ? "bg-red-500" : progress > 80 ? "bg-yellow-500" : "bg-green-500"
                  )}
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      updateState(prev => ({
                        ...prev,
                        budgets: prev.budgets.filter(b => b.category !== budget.category)
                      }));
                    }}
                    className="p-1.5 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500/20 transition-colors"
                    title="Delete Budget"
                  >
                    <Trash2 size={12} />
                  </button>
                  <button className="p-1.5 bg-white/5 rounded-lg hover:bg-white/10 transition-colors">
                    <Lock size={12} className="opacity-50" />
                  </button>
                  <span className="text-[8px] uppercase font-bold opacity-30">Hard Stop Enabled</span>
                </div>
                <button className="text-[10px] font-bold text-blue-400 uppercase hover:underline">Adjust Limit</button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Waste Detection Engine */}
      <div className="p-6 rounded-3xl bg-red-500/5 border border-red-500/20 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-widest text-red-400 flex items-center gap-2">
          <Zap size={14} />
          Waste Detection Engine
        </h3>
        <div className="space-y-3">
          {state.budgets.filter(b => b.spent > b.limit).length > 0 ? (
            state.budgets.filter(b => b.spent > b.limit).map(b => (
              <div key={b.category} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5">
                <div className="flex items-center gap-3">
                  <TrendingDown size={14} className="text-red-500" />
                  <p className="text-xs font-bold">Overspend Detected: {b.category}</p>
                </div>
                <button 
                  onClick={() => setView?.('transactions')}
                  className="text-[10px] font-bold text-red-400 uppercase hover:underline"
                >
                  Review
                </button>
              </div>
            ))
          ) : (
            <div className="flex items-center gap-3 opacity-30 py-2">
              <CheckCircle2 size={14} className="text-green-500" />
              <p className="text-xs font-bold italic">No waste detected in current budgets...</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-zinc-900 border border-white/10 rounded-3xl p-6 w-full max-w-md space-y-4"
          >
            <h3 className="text-xl font-black uppercase tracking-tighter italic">New Budget Limit</h3>
            
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Category</label>
              <input 
                type="text" 
                value={newBudget.category || ''}
                onChange={(e) => setNewBudget(prev => ({ ...prev, category: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="e.g. Shopping, Travel"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase opacity-50 ml-1">Monthly Limit</label>
              <input 
                type="number" 
                value={newBudget.limit || ''}
                onChange={(e) => setNewBudget(prev => ({ ...prev, limit: Number(e.target.value) }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-sm font-bold outline-none"
                placeholder="0.00"
              />
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <button 
                onClick={() => setShowAddModal(false)}
                className="px-6 py-3 rounded-xl font-bold text-xs uppercase hover:bg-white/5 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleAddBudget}
                className="px-6 py-3 bg-green-500 text-black rounded-xl font-bold text-xs uppercase hover:bg-green-400 transition-colors"
              >
                Set Limit
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
