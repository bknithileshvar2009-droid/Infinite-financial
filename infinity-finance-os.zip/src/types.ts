export type TransactionType = 'income' | 'expense';
export type IncomeType = 'active' | 'passive';
export type Frequency = 'daily' | 'weekly' | 'monthly' | 'yearly' | 'one-time';

export interface Transaction {
  id: string;
  amount: number;
  type: TransactionType;
  category: string;
  date: string;
  tags: string[];
  isRecurring: boolean;
  description: string;
}

export interface SubGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
}

export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  priority: 'low' | 'medium' | 'high';
  subGoals: SubGoal[];
}

export interface Budget {
  category: string;
  limit: number;
  spent: number;
}

export interface IncomeSource {
  id: string;
  name: string;
  amount: number;
  type: IncomeType;
  frequency: Frequency;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  isUnlocked: boolean;
  progress: number;
  target: number;
  icon: string;
}

export interface AutomationRule {
  id: string;
  name: string;
  trigger: string;
  action: string;
  active: boolean;
  lastTriggered?: string;
}

export interface UserStats {
  xp: number;
  level: number;
  streak: number;
  lastActiveDate: string;
  totalSaved: number;
  totalSpent: number;
}

export interface AppSettings {
  theme: 'dark' | 'light' | 'neon';
  currency: string;
  security: {
    pin: string;
    gesture: string[];
    isLocked: boolean;
    fakeAppMode: boolean;
    decoyMode: boolean;
    intruderAlert: boolean;
    biometrics: {
      fingerprint: boolean;
      faceId: boolean;
    };
  };
  githubProfile?: string;
  automation: {
    autoSaveEnabled: boolean;
    autoSaveRule: number; // percentage
    riskTriggers: {
      lowBalance: boolean;
      largeExpense: boolean;
      unusualActivity: boolean;
    };
  };
}

export interface Challenge {
  id: string;
  name: string;
  description: string;
  startDate: string;
  durationDays: number;
  isActive: boolean;
}

export interface AppState {
  transactions: Transaction[];
  goals: Goal[];
  budgets: Budget[];
  incomeSources: IncomeSource[];
  achievements: Achievement[];
  automationRules: AutomationRule[];
  challenges: Challenge[];
  stats: UserStats;
  settings: AppSettings;
  vault: {
    transactions: Transaction[];
    balance: number;
  };
}
