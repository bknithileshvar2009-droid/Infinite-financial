import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Target, 
  BarChart3, 
  Settings as SettingsIcon, 
  Shield, 
  Zap, 
  TrendingUp, 
  Lock,
  Calculator,
  Ghost,
  Database,
  Trophy,
  Activity,
  Wallet,
  Menu,
  X,
  LogIn,
  LogOut,
  Cloud,
  CloudOff
} from 'lucide-react';
import { AppState, Transaction, Goal, Budget, IncomeSource, Achievement, UserStats, AppSettings } from './types';
import { loadState, saveState, saveToFirestore, loadFromFirestore } from './store';
import { processAutoCollections } from './lib/autoCollector';
import { auth, loginAnonymously } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Views
import Dashboard from './components/Dashboard';
import TransactionsView from './components/TransactionsView';
import GoalsView from './components/GoalsView';
import AnalyticsView from './components/AnalyticsView';
import BudgetView from './components/BudgetView';
import AutomationView from './components/AutomationView';
import GamificationView from './components/GamificationView';
import GodPanel from './components/GodPanel';
import SettingsView from './components/SettingsView';
import LockScreen from './components/LockScreen';
import CalculatorMode from './components/CalculatorMode';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [state, setState] = useState<AppState>(loadState());
  const [currentView, setCurrentView] = useState('dashboard');
  const [isLocked, setIsLocked] = useState(state.settings.security.isLocked);
  const [isFakeMode, setIsFakeMode] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (!firebaseUser) {
        // Automatically sign in anonymously if no user is present
        const anonymousUser = await loginAnonymously();
        if (anonymousUser) {
          setUser(anonymousUser);
        }
      } else {
        setUser(firebaseUser);
        setIsSyncing(true);
        const cloudState = await loadFromFirestore();
        let finalState = cloudState || state;
        
        // Auto-collect data on load
        finalState = processAutoCollections(finalState);
        
        setState(finalState);
        setIsSyncing(false);
        setLastSyncTime(new Date());
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  useEffect(() => {
    const timer = setTimeout(() => {
      // Periodic auto-collection check
      updateState(prev => processAutoCollections(prev));
    }, 1000 * 60 * 15); // Every 15 mins
    return () => clearTimeout(timer);
  }, []);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
  };

  useEffect(() => {
    saveState(state);
    if (user && !isSyncing) {
      saveToFirestore(state).then(() => {
        setLastSyncTime(new Date());
      });
    }
  }, [state, user, isSyncing]);

  const updateState = (updater: (prev: AppState) => AppState) => {
    setState(prev => {
      const newState = updater(prev);
      return newState;
    });
  };

  const activeTheme = state.settings.theme;

  const themeClasses = useMemo(() => {
    switch (activeTheme) {
      case 'neon':
        return 'bg-black text-green-400 font-mono selection:bg-green-500 selection:text-black';
      case 'dark':
        return 'bg-zinc-950 text-zinc-100 font-sans';
      case 'light':
        return 'bg-zinc-50 text-zinc-900 font-sans';
      default:
        return 'bg-zinc-950 text-zinc-100 font-sans';
    }
  }, [activeTheme]);

  if (isFakeMode) {
    return <CalculatorMode onUnlock={() => setIsFakeMode(false)} />;
  }

  if (isLocked) {
    return (
      <LockScreen 
        pin={state.settings.security.pin} 
        onUnlock={() => setIsLocked(false)} 
        theme={activeTheme}
        biometrics={state.settings.security.biometrics}
      />
    );
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <Dashboard state={state} updateState={updateState} setView={setCurrentView} />;
      case 'transactions': return <TransactionsView state={state} updateState={updateState} showToast={showToast} />;
      case 'goals': return <GoalsView state={state} updateState={updateState} />;
      case 'analytics': return <AnalyticsView state={state} updateState={updateState} />;
      case 'budget': return <BudgetView state={state} updateState={updateState} setView={setCurrentView} />;
      case 'automation': return <AutomationView state={state} updateState={updateState} />;
      case 'gamification': return <GamificationView state={state} updateState={updateState} showToast={showToast} />;
      case 'god-panel': return <GodPanel state={state} updateState={updateState} showToast={showToast} />;
      case 'settings': return <SettingsView state={state} updateState={updateState} showToast={showToast} />;
      default: return <Dashboard state={state} updateState={updateState} setView={setCurrentView} />;
    }
  };

  const navItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'OS' },
    { id: 'transactions', icon: Wallet, label: 'Cash' },
    { id: 'goals', icon: Target, label: 'Goals' },
    { id: 'analytics', icon: BarChart3, label: 'Intel' },
    { id: 'budget', icon: Shield, label: 'Budget' },
    { id: 'automation', icon: Zap, label: 'Auto' },
    { id: 'gamification', icon: Trophy, label: 'XP' },
    { id: 'god-panel', icon: Database, label: 'God' },
    { id: 'settings', icon: SettingsIcon, label: 'Config' },
  ];

  const dockItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'OS' },
    { id: 'transactions', icon: Wallet, label: 'Cash' },
    { id: 'goals', icon: Target, label: 'Goals' },
    { id: 'analytics', icon: BarChart3, label: 'Intel' },
    { id: 'settings', icon: SettingsIcon, label: 'Config' },
  ];

  return (
    <div className={cn("min-h-screen flex flex-col transition-colors duration-500", themeClasses)}>
      {/* Top Bar */}
      <header className="h-14 border-b border-white/10 flex items-center justify-between px-4 sticky top-0 bg-inherit z-50 backdrop-blur-md bg-opacity-80">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsMenuOpen(true)}
            className="p-2 hover:bg-white/10 rounded-xl transition-colors"
          >
            <Menu size={24} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center text-black">
              <Activity size={20} />
            </div>
            <h1 className="text-lg font-bold tracking-tighter uppercase italic">Infinity OS</h1>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end">
            <span className="text-[10px] opacity-50 uppercase tracking-widest">Level {state.stats.level}</span>
            <div className="w-24 h-1 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-500 transition-all duration-1000" 
                style={{ width: `${(state.stats.xp % 1000) / 10}%` }}
              />
            </div>
          </div>
          <button 
            onClick={() => setIsLocked(true)}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            <Lock size={18} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="p-4 max-w-7xl mx-auto w-full"
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Drawer Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className={cn("fixed top-0 left-0 bottom-0 w-72 z-[101] border-r border-white/10 p-6 flex flex-col", themeClasses)}
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <Activity className="text-green-500" />
                  <span className="font-black uppercase italic tracking-tighter">Menu</span>
                </div>
                <button 
                  onClick={() => setIsMenuOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-xl transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 space-y-1 overflow-y-auto no-scrollbar">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentView(item.id);
                      setIsMenuOpen(false);
                    }}
                    className={cn(
                      "w-full flex items-center gap-4 p-4 rounded-2xl transition-all group",
                      currentView === item.id 
                        ? "bg-green-500 text-black font-black italic" 
                        : "text-zinc-400 hover:bg-white/5 hover:text-white"
                    )}
                  >
                    <item.icon size={20} className={cn(currentView === item.id ? "text-black" : "text-green-500")} />
                    <span className="text-sm uppercase tracking-widest">{item.label}</span>
                  </button>
                ))}
              </div>

              <div className="pt-6 border-t border-white/10">
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/5">
                  <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center">
                    {isSyncing ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                      >
                        <Activity size={20} className="text-green-500" />
                      </motion.div>
                    ) : (
                      <TrendingUp size={20} className="text-green-500" />
                    )}
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-bold opacity-40">Auto-Collector</p>
                    <p className="text-[10px] font-black text-green-500 leading-none">
                      {isSyncing ? 'SYNCING...' : 'LIVE & OPTIMIZED'}
                    </p>
                    {lastSyncTime && (
                      <p className="text-[8px] opacity-30 mt-1 uppercase">
                        Saved: {lastSyncTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Stealth Mode Overlay (Optional) */}
      {state.settings.security.decoyMode && (
        <div className="fixed inset-0 pointer-events-none border-4 border-red-500/20 z-[100] animate-pulse" />
      )}

      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className={cn(
              "fixed bottom-24 left-1/2 -translate-x-1/2 z-[200] px-6 py-3 rounded-2xl font-bold text-xs uppercase shadow-2xl border backdrop-blur-md",
              toast.type === 'success' ? "bg-green-500 text-black border-green-400" :
              toast.type === 'error' ? "bg-red-500 text-white border-red-400" :
              "bg-zinc-900 text-white border-white/10"
            )}
          >
            {toast.message}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
