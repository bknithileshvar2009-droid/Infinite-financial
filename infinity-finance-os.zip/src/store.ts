import { AppState, Transaction, Goal, Budget, IncomeSource, Achievement, UserStats, AppSettings } from './types';
import { db, auth } from './firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from './lib/firebaseUtils';

export const INITIAL_STATE: AppState = {
  transactions: [],
  goals: [],
  budgets: [],
  incomeSources: [],
  achievements: [],
  automationRules: [],
  challenges: [],
  stats: {
    xp: 0,
    level: 1,
    streak: 0,
    lastActiveDate: new Date().toISOString(),
    totalSaved: 0,
    totalSpent: 0,
  },
  settings: {
    theme: 'neon',
    currency: '₹',
    security: {
      pin: '',
      gesture: [],
      isLocked: false,
      fakeAppMode: false,
      decoyMode: false,
      intruderAlert: false,
      biometrics: {
        fingerprint: false,
        faceId: false,
      },
    },
    githubProfile: '',
    automation: {
      autoSaveEnabled: false,
      autoSaveRule: 0,
      riskTriggers: {
        lowBalance: true,
        largeExpense: true,
        unusualActivity: false,
      },
    },
  },
  vault: {
    transactions: [],
    balance: 0,
  },
};

const STORAGE_KEY = 'infinity_finance_os_state_v2';

export const mergeState = (savedState: any): AppState => {
  return {
    ...INITIAL_STATE,
    ...savedState,
    settings: {
      ...INITIAL_STATE.settings,
      ...(savedState.settings || {}),
      security: {
        ...INITIAL_STATE.settings.security,
        ...(savedState.settings?.security || {}),
      },
      automation: {
        ...INITIAL_STATE.settings.automation,
        ...(savedState.settings?.automation || {}),
      }
    },
    stats: {
      ...INITIAL_STATE.stats,
      ...(savedState.stats || {}),
    },
    vault: {
      ...INITIAL_STATE.vault,
      ...(savedState.vault || {}),
    },
    automationRules: savedState.automationRules || INITIAL_STATE.automationRules
  };
};

export const loadState = (): AppState => {
  try {
    const serializedState = localStorage.getItem(STORAGE_KEY);
    if (serializedState === null) {
      return INITIAL_STATE;
    }
    const savedState = JSON.parse(serializedState);
    return mergeState(savedState);
  } catch (err) {
    return INITIAL_STATE;
  }
};

export const saveState = (state: AppState) => {
  try {
    const serializedState = JSON.stringify(state);
    localStorage.setItem(STORAGE_KEY, serializedState);
  } catch {
    // Ignore write errors
  }
};

export const saveToFirestore = async (state: AppState) => {
  const user = auth.currentUser;
  if (!user) return;

  const path = `users/${user.uid}`;
  try {
    await setDoc(doc(db, path), {
      ...state,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
};

export const loadFromFirestore = async (): Promise<AppState | null> => {
  const user = auth.currentUser;
  if (!user) return null;

  const path = `users/${user.uid}`;
  try {
    const docSnap = await getDoc(doc(db, path));
    if (docSnap.exists()) {
      return mergeState(docSnap.data());
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
};
